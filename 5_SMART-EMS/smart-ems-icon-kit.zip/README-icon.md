# Smart-EMS ホーム画面アイコン（PWA）導入メモ

識別色「墨（#0A0A0A）」のロゴ（黒地＋白い棒グラフ）を、ホーム画面追加時のアイコンとして使えるようにしました。

## 1. いちばん簡単：本体HTMLだけでOK（外部ファイル不要）
`smart_ems_ver0_21_kashiwa.html` の `<head>` に、アイコン宣言を **data URI で埋め込み済み** です。
追加ファイルは不要で、この **1ファイルを HTTPS で配信するだけ** で、ホーム画面に専用ロゴ＋「Smart-EMS」で並び、全画面で開きます。

埋め込んだ宣言（抜粋）:
```html
<meta name="theme-color" content="#0A0A0A">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="Smart-EMS">
<link rel="apple-touch-icon" href="data:image/png;base64,…">   <!-- iOS -->
<link rel="manifest" href="data:application/manifest+json,…">  <!-- Android/PWA -->
```

## 2. 外部ファイルで配信したい場合（任意）
同梱の画像とマニフェストを、HTMLと同じフォルダに置いて使えます（HTTPS必須）。
- `smart-ems-icon-180.png`（iOS apple-touch-icon用）
- `smart-ems-icon-192.png` / `smart-ems-icon-512.png`（manifest用）
- `smart-ems.webmanifest`（theme_color = #0A0A0A）

その場合は、本体HTMLの埋め込みブロックを次のタグに置き換えてください:
```html
<link rel="manifest" href="smart-ems.webmanifest">
<meta name="theme-color" content="#0A0A0A">
<link rel="apple-touch-icon" href="smart-ems-icon-180.png">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="Smart-EMS">
```
`smart-ems.webmanifest` の `start_url` は本番URLに合わせてください（例 `https://example.com/smart_ems.html`）。

## 3. 利用者の追加方法
- iPhone（Safari）: 共有 → 「ホーム画面に追加」
- Android（Chrome）: ︙ → 「アプリをインストール」/「ホーム画面に追加」

## 注意
- ロゴが反映されるのは **HTTPS配信時**（`http://` や端末ローカルの一部環境では反映されないことがあります）。
- 識別色は「墨 = #0A0A0A」。アプリ本体のテーマ色（トップバー・アクセント）もこの墨に統一済みです。
