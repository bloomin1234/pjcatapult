# SMART AI ── ホーム画面アイコン（PWA）一式

スマホの「ホーム画面に追加」で、専用ロゴ（緑地＋白の名寄せマーク）とアプリ名「SMART AI」が
使われ、全画面アプリのように開くための一式です。

URL の文字列そのものにはロゴは入りません。代わりに、URL が指すページの `<head>` に
「アイコン宣言」を仕込んでおくことで、追加時にこのロゴが使われます。本フォルダの
`smart_ai.html` には、その宣言をすでに差し込み済みです。

---

## 同梱ファイル

- `smart_ai.html` ……… アイコン宣言を差し込み済みの本体（そのまま配信）
- `smart-ai.webmanifest` … アプリ名・アイコン・テーマ色の定義
- `smart-ai-icon-180.png` … iOS ホーム画面用（apple-touch-icon）
- `smart-ai-icon-192.png` … Android／一般アイコン
- `smart-ai-icon-512.png` … 高解像度・マスカブル用

---

## 導入手順

### 1. ファイルを配置
本フォルダの PNG と `.webmanifest` を、`smart_ai.html` と「同じフォルダ」に置きます。
**必ず HTTPS で配信してください**（`http://` や端末ローカルのファイル直開きでは動作しません）。

### 2. `<head>` への宣言（※ smart_ai.html は対応済み）
新規 HTML に手で入れる場合は、`</head>` の直前に次を貼り付けます。

```html
<link rel="manifest" href="smart-ai.webmanifest">
<meta name="theme-color" content="#0F5132">
<link rel="apple-touch-icon" href="smart-ai-icon-180.png">
<link rel="icon" type="image/png" sizes="192x192" href="smart-ai-icon-192.png">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="SMART AI">
<meta name="application-name" content="SMART AI">
```

### 3. 本番 URL に合わせる
`smart-ai.webmanifest` の `start_url` を、配信先の実 URL に合わせます。
例: `"start_url": "https://example.com/smart_ai.html"`

### 4. 利用者の追加方法
- iPhone（Safari）: 共有ボタン → 「ホーム画面に追加」
- Android（Chrome）: ︙メニュー → 「アプリをインストール」／「ホーム画面に追加」

---

## メモ
- テーマ色・アイコン地色は実ロゴと同じ深緑 `#0F5132` に統一しています。
- アイコンは提供いただいた実ロゴ（512px）から各サイズを書き出しました。
- 512px は `purpose: "any maskable"` 指定で、Android の丸型・角丸マスクにも対応します。
